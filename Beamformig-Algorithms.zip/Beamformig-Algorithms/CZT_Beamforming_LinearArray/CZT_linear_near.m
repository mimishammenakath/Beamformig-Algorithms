%-- Function for reconstructing a 2D acoustical near feild image from a linear array data
%-- using Chirp Zeta Transform Beamforming
%-- Authors: Mimisha M Menakath and Mahesh Raveendranatha Panicker
%-- Affiliation: Indian Institute of Technology Palakkad, India
%-------------------------------------------------------------------------%
%-- Version: v1.0
%-- Last modified on 13 - February - 2025
%-------------------------------------------------------------------------%clearvars;

function b= CZT_linear_near(block_data,window_size,fs,d,w)
InputParameters_linear;

%% CZT Beamforoming in frequency dmain
B=zeros(ceil(window_size/2)+1,Mb);      % beam in frequency domain for all fl<=fs/2
Beam_f=zeros(window_size,Mb);           % beam in frequency domain for all frequency bins

%Time domain to frequency domain
S_t=cell2mat(block_data);              % accessing the block of channeldata corresponding to the given range
S_f=fft(S_t,window_size);              % FFT of each channel data
%%   CZT beamforming
  s_alpha=(sin(alpha_f)-sin(alpha_i))/(Mb-1);     %beam spacing along azimuth direction

for l= 1:ceil(window_size/2) +1            % frequency index
    fl=l*fs/window_size;                   % frequency bin corresponding to l
    S=S_f(l,:);                            % l point DFT of each block
        
    Aa=exp((-1i*2*pi*fl*d*sin(alpha_i))/c);
    Wa=exp((1i*2*pi*fl*d*s_alpha)/c);
    
    for p=1:Mb
        W(p)= (Wa)^(-(p-1)^2/2);
    end
    for m=1:M
        C(m)=w(m,l)*S(m)*(Aa)^(m-1)*(Wa)^(-(m-1)^2/2);
    end
    for m=1:Mb
        D(m)= (Wa)^((m-1)^2/2);
    end
   
    %% zero padding

    L1=M+Mb-1;
    C_padded=C;
    C_padded(L1)=0;
    D_padded=D;
    D_padded(L1)=0;
    for m=L1-M+1:L1
        D_padded(m) = D_padded(L1-(m-2));
    end

    C_f=fft(C_padded);
    D_f=fft(D_padded);
    B_f=ifft(C_f.*D_f);
    B(l,:)= W.*B_f(1:Mb);
end
% repeating DFT points using conjugate symmetry property
Beam_f(1:ceil(window_size/2)+1,:)=B;
for i=1:ceil(window_size/2)-1
    Beam_f(ceil(window_size/2)+1+i,:)=conj(B(ceil(window_size/2)+1-i,:));
end
% Frequency domain to time domain conversion
beam=ifft(Beam_f,'symmetric');                                                    % beams in time domain
b=squeeze(beam(ceil(window_size/2),:));                                           % beam corresponding to the given range
b(isnan(b))=0;
b(isinf(b))=0;

