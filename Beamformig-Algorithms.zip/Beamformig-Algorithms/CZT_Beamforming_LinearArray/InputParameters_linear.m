%% Input Paramerers
M=24;                                          %number of sensor elements along x direction                                           %number of sensor elements along y direction
Mb=60;                                         %number of beams in azimuth direction                                       %number of beams in elevation direction
c=1500;                                        %speed of sound in the medium in m/s
alpha_i=-12*pi/180;                            %inital azimuth angle in radian
alpha_f=-alpha_i;                              %final azimuth angle in radian
ds_alpha=(alpha_f-alpha_i)/(Mb-1);             %beam spacing along azimuth direction
s_alpha=(sin(alpha_f)-sin(alpha_i))/(Mb-1);    %beam spacing in sine domain along azimuth direction