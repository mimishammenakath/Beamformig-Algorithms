
clc;
close all;
clearvars

%% GPU CPU Selection
GPU             = false;                                 % set to true to simulate using GPU, to false to simulate in CPU
if(GPU)
    DATA_CAST       = 'gpuArray-single';                % set to 'single' or 'gpuArray-single' to speed up computations
else
    DATA_CAST       = 'single';                         % set to 'single' or 'gpuArray-single' to speed up computations
end

%% create the computational grid
% set the size of the perfectly matched layer (PML)
pml_x_size = 5;                                        % [grid points]
pml_y_size = 5;                                        % [grid points]
                                 % [grid points]
%x=40e-3;                                                % depth in [m] Note: In k-wave depth is in x direction, y is the lateral direction and z is the elevation (out of plane)
dx                  =0.5e-3;                           % [m]
dy                  =0.5e-3;                           % [m]
                        % [m]
Nx                  = 576- 2*pml_x_size;         % [grid points]
Ny                  = 256- 2*pml_y_size;         % [grid points]

kgrid               = kWaveGrid(Nx, dx, Ny, dy);


%% create the time array
c0=1500;                                                % Assumed average speed of sound
cfl                 = 0.3;
t_end = (Nx * dx) * 2.2/ c0;

kgrid.makeTime(c0, cfl, t_end);


%% Medium properties
% define the properties of the propagation medium
rho0 = 1000;                    % [kg/m^3]
alpha_coeff = 0.0022;      % [dB/(MHz^y cm)]
alpha_power = 1.05;
%medium.BonA = 6;


% =========================================================================
% Creating background maps of random scatterers
% =========================================================================
 background_map_mean = 1;
 background_map_std = 0.01;
 background_map = background_map_mean + background_map_std * randn([Nx, Ny]);

% =========================================================================
% Defining medium speed of sound and density
% =========================================================================
%defining marine sediment properties
medium.sound_speed            = c0*ones(Nx, Ny).*background_map;
medium.density                = rho0*ones(Nx, Ny).*background_map;
 
radius = 50;      % grid points
%  scattering_region1 = makeBall(Nx, Ny, Nz, 200, 90, 90, radius);
scattering_region1 = makeDisc(Nx, Ny, 400, Ny/2, radius);

% scattering_region1= zeros(Nx,Ny,Nz);
% scattering_region1(200:250, 90:140,  90:140)=1;
% 
% scattering_region2= zeros(Nx,Ny,Nz);
% scattering_region2(200:250,  160:210,   160:210)=1;

medium.sound_speed(scattering_region1 == 1) =5920;%scattering_c0(scattering_region1 == 1);
medium.density(scattering_region1 == 1) = 7870;

% medium.sound_speed(scattering_region1 == 1) =6000;%scattering_c0(scattering_region1 == 1);
% medium.density(scattering_region1 == 1) = 8000;

medium.sound_speed=smoothn(medium.sound_speed,0.1);
medium.density=smoothn(medium.density,0.1);


medium.alpha_coeff            = alpha_coeff*ones(Nx, Ny);
medium.alpha_power            = alpha_power;

alpha=-12:12;

x=(1:Nx)*dx;
y=(1:Ny)*dy;
figure,imagesc(y,x,medium.sound_speed); % Plotting the speed of sound map
title('Speed of sound map');xlabel('along track distance in meter','FontSize',12,'FontWeight','bold') ;
ylabel('range in meter','FontSize',12,'FontWeight','bold') ;
colorbar;



%% Defining source and sensor
source_freq         = 500e3;      % [Hz]
source_strength     = 100e20;      % [Pa]
source_cycles       = 3;        % number of tone burst cycles
excitation = source_strength*toneBurst(1/kgrid.dt, source_freq, source_cycles);
Bandwidth=powerbw(excitation,1/kgrid.dt);
array_width=72; %transducer array width


source.p_mask=zeros(Nx, Ny);
source.p_mask(1,1:Ny )=1; %Defining as a pressure source
%Note that the source strength is not scaled by acoustic impedance as a pressure source is used (Z=P/V)

%%focused transmiission
% sound_speed=1500;
% x_axis=linspace(min(kgrid.x(:)),max(kgrid.x(:)),size(kgrid.x,1));
% y_axis=linspace(min(kgrid.y(:)),max(kgrid.y(:)),size(kgrid.x,2));
% z_axis=linspace(min(kgrid.z(:)),max(kgrid.z(:)),size(kgrid.x,3));
% focus_position=[x_axis(Nx/2),y_axis(Ny/2),z_axis(Nz/2)];
% input_signal_mat = focus(kgrid, excitation , source.p_mask,focus_position , sound_speed);
% source.p=input_signal_mat;

source.p = excitation;
source.p_mode='dirichlet';

sensor.mask=zeros(Nx, Ny);
sensor.mask(1,(Ny/2 - array_width/2):1:(Ny/2 - array_width/2)+71)=1;


% set the input arguments
input_args = {'PMLSize', pml_x_size, 'PlotPML', false, ...
    'PMLInside', false, 'PlotScale',[-1, 1]*source_strength, ...
    'DataCast', DATA_CAST,  'DataRecast', true,...
    'RecordMovie', false, 'MovieProfile', 'MPEG-4'}; % Video of the simulation will be recorded in the current directory

% run the simulation
sensor_data = kspaceFirstOrder2D(kgrid, medium, source, sensor, input_args{:});
sensor_data_filtered=filtfilt(fliplr(excitation),1,sensor_data');

% create radius variable assuming that t0 corresponds to the middle of the
% input signal
 t0 = length(excitation) * kgrid.dt / 2;
 r = c0 * ( (1:length(kgrid.t_array)) * kgrid.dt / 2 - t0);    % [m]
% 
% define absorption value and convert to correct units
 tgc_alpha_db_cm =alpha_coeff * (source_freq * 1e-6)^alpha_power;
 tgc_alpha_np_m = tgc_alpha_db_cm / 8.686 * 100;

% create time gain compensation function based on attenuation value and
% round trip distance
 tgc = exp((tgc_alpha_np_m) * 2 * r);
% tgc = exp(10 * 2 * r);
% % apply the time gain compensation to each of the scan lines
 
sensor_data_amplified = bsxfun(@times, tgc, sensor_data_filtered');

rawData=sensor_data_amplified';
% rawData=downsample(rawData,3);
x_grid=kgrid.y(:,:);
z_grid=kgrid.x(:,:);
% y_grid=kgrid.z(:,:);
z_grid=z_grid-min(z_grid(:));
% y_grid=y_grid-min(y_grid(:));
x_axis=linspace(min(kgrid.y(:)),max(kgrid.y(:)),size(x_grid,2));
% y_axis=linspace(min(kgrid.z(:)),max(kgrid.z(:)),size(y_grid,3));
temp=x_axis(Ny/2-array_width/2:Ny/2-array_width/2+71);
probe_geometry=linspace(min(temp),max(temp),24)';
% temp=y_axis(Nz/2-array_length/2:Nz/2-array_length/2+71);
% length_probe_geometry=linspace(min(temp),max(temp),24)';
timeVector=kgrid.t_array;
c_map=medium.sound_speed(:,:);
fs=1/kgrid.dt;
d=3*dx;
fc=source_freq;
rawData_resampled=resample(rawData,1,6);
fs=fs/6;
timeVector=(0:size(rawData_resampled,1)-1).*1/fs;
rawData_resampled_1=reshape( rawData_resampled',array_width,[]);
w=gausswin(3); % Guassian window
window=repmat(w,1,size(rawData_resampled,1));
rawData_new=zeros((size(probe_geometry,1)),size(rawData_resampled,1));
for j=1:3:array_width
   rawData_new(ceil(j/3),:)=sum((rawData_resampled_1(j:j+2,:).*window),1);  
end
rawData_new=reshape( rawData_new,array_width/3,[]);

save('czt_linear_data','rawData','rawData_new','timeVector','probe_geometry','fs','d','fc','Nx','Ny');