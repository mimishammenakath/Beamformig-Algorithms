%-- Function for reconstructing a 2D acoustical near field image from a linear array data
%-- using frequency domain direct method
%-- Authors: Mimisha M Menakath and Mahesh Raveendranatha Panicker
%-- Affiliation: Indian Institute of Technology Palakkad, India
%-------------------------------------------------------------------------%
%-- Version: v1.0
%-- Last modified on 13 - February - 2025
%-------------------------------------------------------------------------%clearvars;

function b= DM_linear_near(block_data,window_size,delay,fs,w)
InputParameters_linear;

%% DAS Beamforoming in frequency dmain
delay_compensation=zeros(M,Mb);
% B=zeros(Mb);                            % beam in frequency domain for fl
B_f=zeros(ceil(window_size/2)+1 ,Mb);  % beam in frequency domain for all fl<=fs/2
Beam_f=zeros(window_size,Mb);           % beam in frequency domain for all frequency bins
%Time domain to frequency domain
S_t=cell2mat(block_data);        % accessing the block of channeldata corresponding to the given range
S_f=fft(S_t,window_size);              % FFT of each channel data
% DAS beamforming
for l= 1:ceil(window_size/2) +1            % frequency index
    fl=l*fs/window_size;                   % frequency bin corresponding to l
    S_fl=S_f(l,:);                         % l point DFT of each block
    S=reshape(S_fl,M,1);

    for p=1:Mb                             % azimuth angle selection
        % elevation angle selection
        delay_compensation(:,p)=exp(-1i*2*pi*fl.*(delay(:,p)));   % phase shift to compensate delay
        %             delay_compensated_signal= receive_apodization(:,:,p,q).*S.*delay_compensation(:,:,p,q);
        delay_compensated_signal= w(:,l).*S.*(delay_compensation(:,p));
        B(p)=sum(reshape(delay_compensated_signal,1,[]));               % beam in frequency domain for fl

    end
    B_f(l,:)=B;                                                 % beam in frequency domain for all frequency bins
end

% repeating DFT points using conjugate symmetry property
Beam_f(1:ceil(window_size/2)+1,:)=B_f;
for i=1:ceil(window_size/2)-1
    Beam_f(ceil(window_size/2)+1+i,:)=conj(B_f(ceil(window_size/2)+1-i,:));
end
% Frequency domain to time domain conversion
beam=ifft(Beam_f,'symmetric');                                    % beam in time domain
b=squeeze(beam(ceil(window_size/2),:));                           % beam corresponding to the given range
b(isnan(b))=0;
b(isinf(b))=0;
end
