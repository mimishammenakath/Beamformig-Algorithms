

clearvars;
clc;
% close all;
addpath(genpath('k-wave-toolbox-version-1.3'));
addpath('functions');
addpath('data')
%% input parameters
load('czt_linear_data');
rawData=rawData_new(:,50:end);
rawData=rawData';
% rawData=awgn(rawData,1,'measured');
timeVector=timeVector(50:end);
probe_geometry=probe_geometry';
InputParameters_linear;
%% delay calculation
delay=zeros(M,Mb);
for p=1:Mb                                     % azimuth angle selection
    for m=1:M                              % sensor position in x direction
        sin_alpha_p=sin(alpha_i)+(p-1)*s_alpha;
        delay(m,p)=((m-1)*d*sin_alpha_p)/c;
    end
end

%% partial overlaping
overlap=ceil(fs*((max(delay(:)))))-ceil(fs*(min(delay(:))));        % overlaping parameter
r_res=0.0005;                                                        % range resolution in meter
window_size=ceil(r_res*fs/(0.5*c)+overlap);                               % Number DFT points
Nc=size(rawData,2);                                                   % number of Channels

for k=1:Nc                                                            % channel selection
    channel_data=rawData(:,k);                                        % channel data
    channel_data_len = length(channel_data);                          % number of samples
    advance = window_size - overlap;
    starts = 1 : advance : channel_data_len;
    ends = min(starts + window_size - 1, channel_data_len);
    sensor_data(:,k) = arrayfun(@(S,E) channel_data(S:E), starts, ends, 'uniform', 0); % blocks of channel data
end
%% calculating range using range resolution
range_resolution=window_size-overlap ; % range resolution in number of samples
r_vec = 0.5*c.*timeVector(ceil(window_size/2):range_resolution:end); % range vector
block=(1:length(r_vec));

%% Range dependent delay
W=zeros(M,ceil(window_size/2) +1 ,length(r_vec));
for l= 1:ceil(window_size/2) +1            % frequency index
    fl=l*fs/window_size;
    for r=1:length(r_vec)
        for m=1:M

            W(m,l,r)=exp(1i*2*pi*fl*(((m-1)-(M-1)/2)^2*d^2)/(2*r*c));

        end
    end
end

%% 3D beamforming
beamformed_data=zeros(Mb,length(r_vec));
for r=1:length(r_vec)
    block_number=block(r);
    block_data=sensor_data(block_number,:);
    range=r_vec(r);
    w=squeeze(W(:,:,r));
    beamformed_data(:,r)=DM_linear_near(block_data,window_size,delay,fs,w);

end

%% displaying
envelope=abs(hilbert(beamformed_data));
beamformedDataDASImage=20*log10(envelope/max(envelope(:)));
alpha=rad2deg(alpha_i):rad2deg(ds_alpha):rad2deg(alpha_f);
x=(1:Ny)*0.5;
z=(1:Nx)*0.5;
%gray image
figure,imagesc(x,z,beamformedDataDASImage'); 
title('2D image');xlabel('Along track distance in mm','FontSize',12,'FontWeight','bold') ;
ylabel('Range in mm','FontSize',12,'FontWeight','bold') ; axis equal; axis tight;
colormap(gray);




