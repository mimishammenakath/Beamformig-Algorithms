function beamformed_data=DAS_2D(rawData,timeVector,delay,range_index)

InputParameters;
r=range_index;
%% DAS beamforming
delay_compensation=zeros(M*N,Mb*Nb);
delay_compensated_signal=zeros(M*N,Mb*Nb);

delay=reshape(delay,M*N,Mb*Nb);
for Nc=1:M*N
    delay_compensation(Nc,:)=timeVector(r)-delay(Nc,:);
    delay_compensated_signal(Nc,:)=interp1(timeVector,(rawData(:,Nc))',delay_compensation(Nc,:),'spline',0);
end

beamformed_data=sum(delay_compensated_signal);
beamformed_data=reshape(beamformed_data,Mb,Nb);

end

