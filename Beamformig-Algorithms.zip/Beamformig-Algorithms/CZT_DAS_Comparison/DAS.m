%-- Script for reconstructing single slice at target range of a 3D image from a planar array data
%-- using delay and sum beamforming in time domain beamforming
%-- Authors: Mimisha M Menakath and Mahesh Raveendranatha Panicker
%-- Affiliation: Indian Institute of Technology Palakkad, India
%-------------------------------------------------------------------------%
%-- Version: v1.0
%-- Last modified on 13 - February - 2025
%-------------------------------------------------------------------------%
% clearvars;
clc;
close all;


%% input parameters
load('ball_mildsteel');
rawData=rawData_new(50:end,:);
timeVector=timeVector(50:end);
InputParameters;
% rawData=rawData';
% width_probe_geometry=width_probe_geometry';
% length_probe_geometry=length_probe_geometry';
%% delay calculation
delay=zeros(M,N,Mb,Nb);
for p=1:Mb                                     % azimuth angle selection
    for q=1:Nb                                 % elevation angle selection
        for m=1:M                              % sensor position in x direction
            for n=1:N                          % sensor poistion in y direction
                sin_alpha_p=sin(alpha_i)+(p-1)*s_alpha;
                sin_beta_q=sin(beta_i)+(q-1)*s_beta;
                delay(m,n,p,q)=((m-1)*d*sin_alpha_p+ (n-1)*d*sin_beta_q)/c;
                
            end
        end
    end
end
      
%% Beamforming
beamformed_data=zeros(Mb,Nb);
range_index=450;
tic
beamformed_data(:,:)=DAS_2D(rawData,timeVector,delay,range_index);
toc


