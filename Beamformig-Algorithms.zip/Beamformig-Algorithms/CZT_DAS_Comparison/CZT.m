%-- Script for reconstructing single slice at target range of a 3D acoustical image from a planar array data
%-- using Chirp Zeta Transform Beamforming
%-- Authors: Mimisha M Menakath and Mahesh Raveendranatha Panicker
%-- Affiliation: Indian Institute of Technology Palakkad, India
%-------------------------------------------------------------------------%
%-- Version: v1.0
%-- Last modified on 13 - February - 2025
%-------------------------------------------------------------------------%clearvars;
clearvars;
clc;
close all;

%% input parameters
load('ball_mildsteel');
rawData=rawData_new(50:end,:);
timeVector=timeVector(50:end);
InputParameters;

%% delay calculation
delay=zeros(M,N,Mb,Nb);
for p=1:Mb                                     % azimuth angle selection
    for q=1:Nb                                 % elevation angle selection
        for m=1:M                              % sensor position in x direction
            for n=1:N                          % sensor poistion in y direction
                sin_alpha_p=sin(alpha_i)+(p-1)*s_alpha;
                sin_beta_q=sin(beta_i)+(q-1)*s_beta;
                delay(m,n,p,q)=((m-1)*d*sin_alpha_p+ (n-1)*d*sin_beta_q)/c;
            end
        end
    end
end
%% partial overlaping
% overlap=ceil(fs*((max(delay(:)))))-ceil(fs*(min(delay(:))));        % overlaping parameter
% overlap=0;
% r_res=0.0005;                                                        % range resolution in meter
% window_size=ceil(r_res*fs/(0.5*c)+overlap);                               % Number DFT points
% Nc=size(rawData,2);                                                   % number of Channels
% 
% for k=1:Nc                                                            % channel selection
%     channel_data=rawData(:,k);                                        % channel data
%     channel_data_len = length(channel_data);                          % number of samples
%     advance = window_size - overlap;
%     starts = 1 : advance : channel_data_len;
%     ends = min(starts + window_size - 1, channel_data_len);
%     sensor_data(:,k) = arrayfun(@(S,E) channel_data(S:E), starts, ends, 'uniform', 0); % blocks of channel data
% end
%% calculating range using range resolution
window_size=size(rawData,1);
%% 3D beamforming
beamformed_data=zeros(Mb,Nb);
r=450;
tic
beamformed_data=CZT_2D(rawData,window_size,fs,d,r);
toc
