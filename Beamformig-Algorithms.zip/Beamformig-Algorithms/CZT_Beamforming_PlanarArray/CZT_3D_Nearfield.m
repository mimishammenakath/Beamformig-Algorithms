%-- Script for reconstructing 3D acoustical near feild image from a planar array data
%-- using Chirp Zeta Transform (CZT) beamforming
%-- Authors: Mimisha M Menakath and Mahesh Raveendranatha Panicker
%-- Affiliation: Indian Institute of Technology Palakkad, India
%-------------------------------------------------------------------------%
%-- Version: v1.0
%-- Last modified on 13 - February - 2025
%-------------------------------------------------------------------------%

clearvars;
clc;
close all;
%% input parameters
load('Z_data');
rawData=rawData_new(50:end,:);
timeVector=timeVector(50:end);
width_probe_geometry=width_probe_geometry';
length_probe_geometry=length_probe_geometry';
InputParameters;
%% delay calculation
delay=zeros(M,N,Mb,Nb);
for p=1:Mb                                     % azimuth angle selection
    for q=1:Nb                                 % elevation angle selection
        for m=1:M                              % sensor position in x direction
            for n=1:N                          % sensor poistion in y direction
                sin_alpha_p=sin(alpha_i)+(p-1)*s_alpha;
                sin_beta_q=sin(beta_i)+(q-1)*s_beta;
                delay(m,n,p,q)=((m-1)*d*sin_alpha_p+ (n-1)*d*sin_beta_q)/c;
            end
        end
    end
end
%% partial overlaping
overlap=ceil(fs*((max(delay(:)))))-ceil(fs*(min(delay(:))));          % overlaping parameter
r_res=0.0005;                                                         % range resolution in meter
window_size=ceil(r_res*fs/(0.5*c)+overlap);                           % Number of DFT points
Nc=size(rawData,2);                                                   % number of Channels

for k=1:Nc                                                            % channel selection
    channel_data=rawData(:,k);                                        % channel data
    channel_data_len = length(channel_data);                          % number of samples
    advance = window_size - overlap;
    starts = 1 : advance : channel_data_len;
    ends = min(starts + window_size - 1, channel_data_len);
    sensor_data(:,k) = arrayfun(@(S,E) channel_data(S:E), starts, ends, 'uniform', 0); % blocks of channel data
end
%% calculating range using range resolution
range_resolution=window_size-overlap ; % range resolution in number of samples
r_vec = 0.5*c.*timeVector(ceil(window_size/2):range_resolution:end); % range vector
block=(1:length(r_vec));
%% Range dependent delay
W=zeros(M,ceil(window_size/2) +1,length(r_vec));
for l= 1:ceil(window_size/2) +1            % frequency index
    fl=l*fs/window_size;
    for r=1:length(r_vec)
        for m=1:M
            for n=1:N
                W(m,n,l,r)=exp(1i*2*pi*fl*(((m-1)-(M-1)/2)^2+((n-1)-(N-1)/2)^2)*d^2/(2*r*c));
            end
        end
    end
end
%% 3D beamforming
beamformed_data=zeros(Mb,Nb,length(r_vec));
for r=1:length(r_vec)
    block_number=block(r);
    block_data=sensor_data(block_number,:);
    range=r_vec(r);
    w=squeeze(W(:,:,:,r));
    tic
    beamformed_data(:,:,r)=CZT_2D_near(block_data,window_size,fs,d,w);
    time(r)=toc;
end
avg_time=mean(time)/(Mb*Nb);
