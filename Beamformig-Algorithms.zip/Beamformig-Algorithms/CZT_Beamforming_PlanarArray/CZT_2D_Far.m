
%-- Function for reconstructing single slice at target range of a 3D acoustical farfeild image from a planar array data
%-- using Chirp Zeta Transform Beamforming
%-- Authors: Mimisha M Menakath and Mahesh Raveendranatha Panicker
%-- Affiliation: Indian Institute of Technology Palakkad, India
%-------------------------------------------------------------------------%
%-- Version: v1.0
%-- Last modified on 13 - February - 2025
%-------------------------------------------------------------------------%clearvars;
function b= CZT_2D_Far(block_data,window_size,fs,d)
InputParameters;
%% CZT Beamforoming in frequency dmain
B=zeros(ceil(window_size/2)+1 ,Mb,Nb);     % beam in frequency domain for all fl<=fs/2
Beam_f=zeros(window_size,Mb,Nb);           % beam in frequency domain for all frequency bins

%Time domain to frequency domain
S_t=cell2mat(block_data);              % accessing the block of channeldata corresponding to the given range
S_f=fft(S_t,window_size);              % FFT of each channel data
%%   CZT beamforming
C=zeros(M,N);
D=zeros(M,N);
% CZT beamforming
for l= 1:ceil(window_size/2) +1            % frequency index
    fl=l*fs/window_size;                   % frequency bin corresponding to l
    S_fl=S_f(l,:);                         % l point DFT of each block
    S=reshape(S_fl,M,N);
    Aa=exp((-1i*2*pi*fl*d*sin(alpha_i))/c);
    Wa=exp((1i*2*pi*fl*d*s_alpha)/c);
    Ae=exp((-1i*2*pi*fl*d*sin(beta_i))/c);
    We=exp((1i*2*pi*fl*d*s_beta)/c);

    for p=1:Mb
        for q=1:Nb
            W(p,q)= (Wa)^(-(p-1)^2/2).* (We)^(-(q-1)^2/2);
        end
    end
    for m=1:M
        for n=1:N
            C(m,n)= S(m,n)*(Aa)^(m-1)*(Ae)^(n-1)*(Wa)^(-(m-1)^2/2)*(We)^(-(n-1)^2/2);
        end
    end
    for m=1:Mb
        for n=1:Nb
            D(m,n)= (Wa)^((m-1)^2/2)*(We)^((n-1)^2/2);
        end
    end
    
    L1=2*N+Nb-2; % length of padded signal
    C_padded=C;
    C_padded(L1,L1)=0;
    D_padded=D;
    D_padded(L1,L1)=0;

    for m=L1-M+1:L1
        D_padded(m,:) = D_padded(L1-(m-2),:);
    end
    for n = L1-N+1:L1
        D_padded(:,n) = D_padded(:,L1-(n-2));
    end

    C_f=fft2(C_padded);
    D_f=fft2(D_padded);
    B_f=ifft2(C_f.*D_f);
       B(l,:,:)= W.*B_f(1:Mb,1:Nb);
end

% repeating DFT points using conjugate symmetry property
Beam_f(1:ceil(window_size/2)+1,:,:)=B;
for i=1:ceil(window_size/2)-1
    Beam_f(ceil(window_size/2)+1+i,:,:)=conj(B(ceil(window_size/2)+1-i,:,:));
end
% Frequency domain to time domain conversion
beam=ifft(Beam_f,'symmetric');                                    % beam in time domain
b=squeeze(beam(ceil(window_size/2),:,:));                         % beam corresponding to the given range
b(isnan(b))=0;
b(isinf(b))=0;

